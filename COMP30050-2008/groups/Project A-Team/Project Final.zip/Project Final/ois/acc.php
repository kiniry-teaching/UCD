<?php
//@: oisin
if($_POST['submit'] == "Submit")
{
//data for variables
$name = $_POST['name'];
$email = $_POST['email'];
$surname = $_POST['surname'];
$username = $_POST['username'];
$password = $_POST['password'];

//connect and open database
include('./configuration/config.php');
include('./configuration/opendb.php');

//select the database to use
$db = mysql_select_db($dbname, $connection);

//sql insert
$sqlInsert = "INSERT INTO User_Accounts(name, email, surname, username, password) VALUES ('$name', '$email', '$surname', '$username', '$password')";

//store the result of the query
$rs = mysql_query($sqlInsert, $connection);

//if succesful or unsuccesful
if (mysql_affected_rows($connection) == -1){

echo "An error has occured. Record insert failed";
}else{

echo "Record inserted successfully";

}

//close connection
include('./configuration/closedb.php');
}//end if

?>

<!DOCTYPE html PUBLIC "-//W3C/DTD/XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml11-transitional.dtd">
	
	
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>Account Test Page</title>

  
</head>
 
 <body>
 
 <form action="acc.php" method="post">
 <p>Enter your First name, surname, email address, a username and a password</p>
 <br>
 Name: <input type="text" size="20" name="name"/><br>
 Surname: <input type="text" size = "20" name="surname"/><br>
 Email: <input type="text" size = "20" name="email"/><br>
 Username: <input type="text" size="20" name="username"/><br>
 Password: <input type="text" size="20" name="password"/><br>
 <input type="submit" value="Submit" name="submit"/><br>
 
  </form>
  
 

</body>
</html>
