<?php
//@: oisin
//connect and open database
include('./configuration/config.php');
include('./configuration/opendb.php');


$sqlSelect = "SELECT username, points FROM User_Accounts ORDER by points DESC";
//$sqlSelect = "SELECT FROM User_Accounts('username', 'points') 
$rs = mysql_query($sqlSelect, $connection);


?>

<html>
<title>
LeaderBoard
</title>
<body>

<h1>
Leader Board
</h1>
<table>
<tr><td width="20">Place</td><td width="100">User</td><td width="100">Points</td></tr>
<?php
//counter for number of poeplee in leaderboard
$i = 1;
//while still pople left to go through keep displaying names
while($row = mysql_fetch_array($rs)){
	//prin out username and piints in a table ordered by points
	echo "<tr><td>$i</td><td>".$row['username']."</td><td>".$row['points']."</td></tr>";
	$i++;//increase i
}
//close connection
include('./configuration/closedb.php');
?>
</table>
<br><br>

</body>
</html>
