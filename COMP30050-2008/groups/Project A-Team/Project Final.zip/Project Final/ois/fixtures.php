<?php
//@: oisin
//connect and open database
include('./configuration/config.php');
include('./configuration/opendb.php');


$sqlSelect = "SELECT first_team, second_team, end_time FROM Matches ORDER by match_id DESC";
 
$rs = mysql_query($sqlSelect, $connection);


?>

<html>
<title>
Fixtures
</title>
<body>

<h1>
Fixtures
</h1>
<br><br><br>
<table>
<tr><td width="200">First Team</td><td width="10"></td><td width="200">Second Team</td><td width="100">Kick Off</td></tr>
<?php

//while still pople left to go through keep displaying names
while($row = mysql_fetch_array($rs)){
	//print out team names and kick off time
	echo "<tr><td>".$row['first_team']."</td><td>vs</td><td>".$row['second_team']."</td><td>".$row['end_time']."</td></tr>";
	
}
//close connection
include('./closedb.php');
?>
</table>
<br><br>
<a href="./configuration/index.html">Home</a>

</body>
</html>
