<?php
//@: oisin
include("./configuration/config.php");
include("./configuration/opendb.php");

if($do_login){

$login = striplashes($login);
$password = striplashes($password);

$chk = mysql_query("SELECT FROM User_Accounts WHERE login = '$login' LIMIT 1;");
$user = mysql_fetch_array($chk);

if($user[password] == md5($password)){

setcookie("login", "$login", time() + 360000);
setcookie("pass", "$password", time() + 360000);
header("Location: ./userpage.php");
}else{
print "Password or login inccorect!\n";
exit;
}
}


?>



<html>
<head>
<link rel="stylesheet" type="text/css" href="spl.css" />
<title>
Login
</title>
</head>
<body>
Login page

<a href="./index.html"> Home</a>

<form name = "Login" action="login.php" method="post">
 <table border="0">
 <tr>
  <td>username: </td>
  <td><input type="text" name="login"/></td>
 </tr>
 <tr>
  <td>Password : </td>
  <td><input type="password" name="password"/></td>
 </tr>
</table>
 <input type="submit" name="do_login" value="Login"/>    		
 </form>

</body>
</html>
