<html>

<!-- Author: Sean Tracey, Alan McPhilips --> 

<head>
<link rel="stylesheet" type="text/css"
href="spl.css" />
<title>Sports Prediction League || Home Page</title>

</head>
<body>
<h6>
Welcome to the UCD Sports Prediction League!</h6>
<table border="0" width="100%">
<tr>
<td width="30%> </td>
</tr>
<tr>
<td width="70%">
<p><h3>
The Sports Prediction League is a university project designed and built by <a href= "aboutus.php">the SPL team</a>, four devilishly handsome 3rd year CS students in UCD.The rules are simple- Predict results correctly (or as accurately as possible) and you will receive points.
The more points you have, the higher up on the <a href= "leaderboard.php">leaderboard</a> you will go.
Find a more detailed explanation of the game and its rules <a href= "rules.php">here</a>.
</p>
<a href="./login.php">Login</a>
<p>
<a href = "registration.php">Registration</a> is free, so why not sign up?
<p>
<a href = "getFixtures.php">dapper test</a>
</td>
</p>




</body>
</html>
