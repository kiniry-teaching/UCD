<html>
<!-- Author: Sean Tracey, Alan McPhilips --> 
<head>
<link rel="stylesheet" type="text/css"
href="spl.css" />
<title>: account :</title>
<head>


<body>

This page will allow the user to view and edit their e-mail address, username and password.
</body>

</html>
