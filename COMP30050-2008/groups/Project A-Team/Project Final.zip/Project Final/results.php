<html>
<!-- Author: Sean Tracey, Alan McPhilips --> 
<head>
<title>: results :</title>
<link rel="stylesheet" type="text/css"
href="spl.css" />
</head>

<body>

Results of the sports fixtures will be displayed here.

</body>

</html>
