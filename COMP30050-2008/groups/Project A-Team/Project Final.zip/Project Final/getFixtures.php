

<html>
<title>
dapper test
</title>
<body>
does stuff

<?php

/*
Author: Mark Costello
*/

header( 'content-type: text/plain' );
echo "<pre>";
//change location later
require_once "./dappersdk/Dapp.php";
//require_once "/usr/local/www/data/peter/includes/Dapp.php" ;
// The Dapp constructor throws Exceptions - so we should catch it
try {
  	  // Perform a search for  "matches" using variable arguments
	  echo "Performing Search for 'matches' using variable arguments\n";
	  $dappa = new Dapp( 'TheDapp', null );
	  $domDoc = $dappa->getDOM();
//end of the DAPP		


//from here on DOM manipulation
	  $matches = $domDoc->getElementsByTagName( 'match' );
	  echo $matches->length . "\n";

/*
	DOM document: http://ie.php.net/manual/en/class.domdocument.php

	
	DOMList returned by getElementsByTagNam which containts Dom nodes 
	http://ie.php.net/manual/en/class.domnodelist.php

	DOM node http://ie.php.net/manual/en/class.domnode.php
*/
	
	for ($i = 0; $i < $matches->length; $i++) {

		$nodeNames = array( 'date', 'fixture', 'result' );

		$database_values = array();
		foreach( $nodeNames as $nodeName ){
			$nodes = $matches->item( $i )->getElementsByTagName( $nodeName );
			for ($j = 0; $j < $nodes->length; $j++) {
				//echo "$nodeName: ".$nodes->item( $j )->nodeValue . "\n";
				$database_values[ $nodeName ] = $nodes->item( $j )->nodeValue;
			}
		}

		//print_r( $database_values );
		echo 'Date: ' . $database_values['date'] . ', Fixture: ' . $database_values['fixture'] . "\n";

		

		$dates = $matches->item( $i )->getElementsByTagName('date');
		for ($j = 0; $j < $dates->length; $j++) {
			echo "Date: ".$dates->item( $j )->nodeValue . "\n";
		}

		$childnodes = $matches->item( $i )->childNodes;
		for ($j = 0; $j < $childnodes->length; $j++) {
			//echo 'Node: ' . $childnodes->item( $j )->nodeName . ', Value: '. $childnodes->item( $j )->nodeValue . "\n";
		}

	}

  echo "\n";
} catch( Exception $e ) {
    echo 'Caught exception: ',  $e->getMessage(), "\n";
}

?>

</body>
</html>
