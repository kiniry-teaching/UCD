<?php
/* Author: Sean Tracey, Alan McPhilips*/
if(isset($HTTP_COOKIE_VARS["login"]){
?>


<html>

<head>

<title>
userpage???
</title>
<head>

<body>



</body>
</html>


<?
}else{
?>
nothing for you here!
<?
}
?>
