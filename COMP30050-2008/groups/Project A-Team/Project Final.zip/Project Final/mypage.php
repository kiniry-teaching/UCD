<html>
<!-- Author: Sean Tracey, Alan McPhilips --> 
<head>
<title: my page :></title>
<link rel="stylesheet" type="text/css"
href="spl.css" />
</head>
<body>

This page will display information about the users results, as well as a <a href= "account.html">link</a> to editting their given information (mobile number, emails changes etc)


</body>
</html>
