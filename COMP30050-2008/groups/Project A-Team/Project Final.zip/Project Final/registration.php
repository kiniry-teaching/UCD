<?php
/* Author: Ois�n McDermott, Sean Tracey, Alan McPhilips */
if($_POST['submit'] == "Submit")
{
//data for variables
$name = $_POST['name'];
$email = $_POST['email'];
$surname = $_POST['surname'];
$username = $_POST['username'];
$password = $_POST['password'];

//connect and open database
include('./configuration/config.php');
include('./configuration/opendb.php');

//select the database to use
$db = mysql_select_db($dbname, $connection);

//sql insert
$sqlInsert = "INSERT INTO User_Accounts(username, password) VALUES ('$username', '$password')";

//store the result of the query
$rs = mysql_query($sqlInsert, $connection);

//if succesful or unsuccesful
if (mysql_affected_rows($connection) == -1){

echo "An error has occured. Record insert failed";
}else{

echo "Record inserted successfully";

}

//close connection
include('./configuration/closedb.php');
}//end if

?>


<html>
<!-- Author: Sean Tracey, Alan McPhilips --> 
<head>
<link rel="stylesheet" type="text/css"
href="spl.css" />
<title>:account creation:</title>
</head>
<body>



<form  method="post">
 <table border="0">
 <tr>
  <td>Enter username: </td>
  <td><input type="text" name="username"/></td>
 </tr>
 <tr>
  <td>Create Password (Min. of 6 characters): </td>
  <td><input type="password" name="password"/></td>
 </tr>
</table>
 <input type="submit" name="submit" value="Submit"/>    		
 </form>

<h2>
All fields are mandatory.
This is a college project, so we won't be selling</br> your email address or other personal information to any evil corporations.</br>

Probably!!
</h2>

</body>
</html>

