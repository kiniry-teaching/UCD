<html>
<!-- Author: Sean Tracey, Alan McPhilips --> 
<head>
<title>: index :</title>
</head>

<frameset cols = "16%, *" frameborder ="1">
<
<frame noresize="noresize" src="navigation.php">
<frame noresize="noresize" src="home.php" 
	name ="linkage">
<frame src="aboutus.php"
	name ="linkage">


</frameset>
</html>
