<html>
<!-- Author: Sean Tracey, Alan McPhilips --> 
<head>
<link rel="stylesheet" type="text/css"
href="spl.css" />
<title>: about us :</title>
</head>
<body>

This page will display information about the team behind the SPL
<table border="0">
<tr>
<td><img src = "http://csserver.ucd.ie/~a03bf5d9/Alan.jpg" width="70" height="70" >
</td>
<td> Sean Tracey </td>
</tr>

</body>
</html>
