<?
/* Author: Ois�n McDermott */
session_start();
session_destroy();
echo "byr";
?>

<html>
<!-- Author: Sean Tracey, Alan McPhilips --> 
<head>
<link rel="stylesheet" type="text/css"
href="spl.css" />

<title>:bye:</title>

</head>


<body>


<h3><b>You have been successfully logged out</b>
<br/>



<p>Thanks for playing- Make sure you've placed your <a href = "mypage.php">predictions</a> for the next set of matches,<br> and make sure you <a href = "results.php">check</a> them next week!<br/>
Take care
</p>


</br>~SPL

</body>

</html>
