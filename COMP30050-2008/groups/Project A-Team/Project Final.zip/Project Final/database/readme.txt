This is the database containing all the test data.
The host will need to be changed to where ever the databsee is hosted, along with a correct user name adn password to be able to access the databse on the mysql server.
These can be changed in ./configuration/config.php
