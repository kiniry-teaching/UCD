-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- Author: Oisin McDermott -05535310
-- Host: localhost
-- Generation Time: Apr 28, 2008 at 03:32 PM
-- Server version: 5.0.45
-- PHP Version: 4.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `Eminsm_sigma`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `Bets`
-- 

CREATE TABLE `Bets` (
  `acc_id` int(10) unsigned NOT NULL COMMENT 'the acc_id of the person who made the bet',
  `bet_id` int(10) unsigned NOT NULL auto_increment COMMENT 'The unique number that defines what bet is which',
  `match_id` int(10) unsigned NOT NULL COMMENT 'The id number of the match which the bet is being placed on',
  `first_score` int(10) unsigned NOT NULL,
  `second_score` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`bet_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC COMMENT='Holds the list of all bets made by users through the Website' AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `Bets`
-- 

INSERT INTO `Bets` (`acc_id`, `bet_id`, `match_id`, `first_score`, `second_score`) VALUES 
(2, 1, 3, 12, 15),
(1, 2, 5, 24, 30),
(1, 3, 4, 18, 12),
(4, 4, 1, 18, 10);

-- --------------------------------------------------------

-- 
-- Table structure for table `Matches`
-- 

CREATE TABLE `Matches` (
  `match_id` int(10) unsigned NOT NULL auto_increment COMMENT 'the unique id of each fixture',
  `first_team` varchar(50) NOT NULL COMMENT 'the first team in the fixture',
  `second_team` varchar(50) NOT NULL COMMENT 'second team in the fixture',
  `first_score` int(10) unsigned NOT NULL default '0' COMMENT 'the first teams score at the end of the match',
  `second_score` int(10) unsigned NOT NULL default '0' COMMENT 'second teams score at the end of the match',
  `fixture_date` date NOT NULL COMMENT 'the date match is happening on',
  `end_time` time NOT NULL COMMENT 'time match should be over at',
  `start_time` time NOT NULL COMMENT 'time for match to kick off',
  PRIMARY KEY  (`match_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='list of fixtures' AUTO_INCREMENT=9 ;

-- 
-- Dumping data for table `Matches`
-- 

INSERT INTO `Matches` (`match_id`, `first_team`, `second_team`, `first_score`, `second_score`, `fixture_date`, `end_time`, `start_time`) VALUES 
(1, 'Munster', 'Ospreys', 0, 0, '0000-00-00', '22:50:00', '00:00:00'),
(2, 'Ospreys', 'Dragons', 0, 0, '0000-00-00', '22:55:00', '00:00:00'),
(3, 'Ulster', 'Munster', 0, 0, '0000-00-00', '22:50:00', '00:00:00'),
(4, 'Connacht Rugby', 'Carrdiff Blues', 0, 0, '0000-00-00', '20:50:00', '00:00:00'),
(5, 'Ospreys', 'Edinburgh Rugby', 0, 0, '0000-00-00', '20:30:00', '00:00:00'),
(6, 'Llanelli Scarlets', 'Munster', 0, 0, '0000-00-00', '16:00:00', '00:00:00'),
(7, 'Ulster', 'Glasgow Warriors', 0, 0, '0000-00-00', '16:10:00', '00:00:00'),
(8, 'Leinster', 'Dragons', 0, 0, '0000-00-00', '19:40:00', '00:00:00');

-- --------------------------------------------------------

-- 
-- Table structure for table `User_Accounts`
-- 

CREATE TABLE `User_Accounts` (
  `acc_id` int(10) unsigned NOT NULL auto_increment COMMENT 'The number of the account. Primary key as each account must be unique',
  `name` varchar(30) NOT NULL COMMENT 'users first anme, limited to 30 characters',
  `surname` varchar(30) NOT NULL COMMENT 'users surname',
  `email` varchar(50) NOT NULL COMMENT 'the users email address',
  `password` varchar(20) NOT NULL COMMENT 'the password to the account',
  `points` int(10) unsigned NOT NULL default '0' COMMENT 'the number of points the user has accquired',
  `username` varchar(30) NOT NULL,
  PRIMARY KEY  (`acc_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=9 ;

-- 
-- Dumping data for table `User_Accounts`
-- 

INSERT INTO `User_Accounts` (`acc_id`, `name`, `surname`, `email`, `password`, `points`, `username`) VALUES 
(1, 'Oisin', 'McDermott', 'oisin@ucd.ie', 'test1', 120, 'ois'),
(2, 'Sean', 'Tracey', 'seant@gmail.com', 'test2', 350, 'Tracey'),
(4, 'Osin', 'McD', 'sigmadark@gmail.com', 'ass', 300, 'sigmad'),
(5, 'Alan', 'McP', 'alan.mcp@ucd.ie', 'test1', 100, 'alan'),
(6, 'Mark', 'Cos', 'mc@gmail.com', 'test2', 130, 'cos'),
(7, 'sema', 'asa', 'saas', 'asas', 0, 'asas'),
(8, 'Test2', 'test2', 'sdhfbhslh', 'sdhvbsd', 0, 'sbflhsd');

