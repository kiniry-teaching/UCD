<html>
<!-- Author: Sean Tracey, Alan McPhilips --> 
<head>

<link rel="stylesheet" type="text/css"
href="spl.css" />

<title>Sports Prediction League || About Us</title>

</head>

<body>

 <h3>
 We are the team behind the creation of the sports prediction league<br>

<table border="0">
<tr>
<td><img src="http://csserver.ucd.ie/~a03bf5d9/Seanpicfinal.jpg" width="150" height="150">

</td>
<td> Sean Tracey </td>
</tr> 
<tr>
<td><img src="http://csserver.ucd.ie/~a03bf5d9/Oisinpic.jpg" width="150" height="150">

</td>
<td> Oisin McDermott </td>
</tr> 
<tr>
<td><img src="http://csserver.ucd.ie/~a03bf5d9/Mark.jpg" width="150" height="150">

</td>
<td> Mark Costello </td>
</tr> 
<tr>
<td><img src="http://csserver.ucd.ie/~a03bf5d9/Alan.jpg" width="150" height="150">

</td>
<td> Alan McPhillips </td>
</tr> 

<tr>
<td><img src="http://csserver.ucd.ie/~a03bf5d9/Benoit.png ">

</td>
<td> Benoit (Our Leader) </td>
</tr> 
</table>


</body>

</html>
