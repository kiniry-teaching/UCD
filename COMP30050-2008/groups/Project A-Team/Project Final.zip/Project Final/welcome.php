<html>
<!-- Author: Sean Tracey, Alan McPhilips --> 
<head><link rel="stylesheet" type="text/css"
href="spl.css" />

<title>: welcome :</title>
</head>

<?php
   
//Determine if the sumbit button has been clicked. If so, begin validating form data.
   
  //   if ($_POST['submitB'] == "Submit")
  {
     //Determine if a Name was entered
     
		$valid_form = true;
     
		
		if ($_REQUEST['uname'] == "") {
			echo "Enter a user name" ."<br/>";
			$valid_form = false;

		
		}
		
		else {
			$username = $_REQUEST['uname'];
		}
		
		if ($_REQUEST['pass'] == "") {
		
			echo "Enter a password"."<br/>";
			$valid_form = false;
		
		}
		
		elseif (strlen($_REQUEST['pass']) < 6) {
			
			echo "Password must contain at least 6 characters";
			$valid_form = false;
		}
		
		else {
			$password = $_REQUEST['pass'];
		}
		
		
		//if all form fields were submitted properly, begin processing
		
		if($valid_form == true)
		{
		echo "Welcome to PHP";
			//form processing code goes here
		
		}
  }
?>


		  
</html>
