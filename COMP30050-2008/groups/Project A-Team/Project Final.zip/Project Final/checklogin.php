<?php
/* Author: Ois�n McDermott */


//Load databse information and then connect to it
include("./configuration/config.php");
include("./configuration/opendb.php");


// username and password sent from form
$myusername=$_POST['myusername'];
$mypassword=$_POST['mypassword'];

$myusername = stripslashes($myusername);
$mypassword = stripslashes($mypassword);
$myusername = mysql_real_escape_string($myusername);
$mypassword = mysql_real_escape_string($mypassword);

//find the user in the database
$sql="SELECT * FROM User_Accounts WHERE username='$myusername' and password='$mypassword'";
//store the result
$result=mysql_query($sql);

// count the number of rows returned by the query, it should be one if its a correct user
$count=mysql_num_rows($result);


if($count==1){
// Register $myusername, $mypassword 
session_register("myusername");
session_register("mypassword");
header("location:success.php");//redirect
}
else {
//not a user/wrong password
echo "Wrong Username or Password";
}
include("./configuration/closedb.php"); //close connection to the database

?>