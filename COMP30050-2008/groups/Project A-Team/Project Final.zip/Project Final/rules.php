<html>
<!-- Author: Sean Tracey, Alan McPhilips --> 
<head>
<link rel="stylesheet" type="text/css"
href="spl.css" />

<title>Sports Prediction League || Rules
</title>

</head>

<body>
<h3> Welcome to Sports Prediction League.<br/> This game is designed
 for fans who think they know how every game will end to show how well 
they really know the game. The rules are simple, all you have to do is <a href = "register.php">
Register</a> and start predicting.<br> The scoring works like this:<br>

-1 point for correct result. (Called a draw on the league table) <br>

-10 points for the correct score. (Called a win on the league table)<br>

-4 Points for the correct home/away score or within 3 points.<br>

-3 Points for guessing the home/away score within 4-6 points.<br>

-2 Points for guessing the home/away score within 7-10 points.<br>

-0 points for guessing the home/away score by more then 10 points.</h3>

</body>

</html>
