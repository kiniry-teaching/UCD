<?php
//Authoer: OisinMcD
$dbhost = "sql6.hosting365.ie";
$dbuser = "Eminsm_sigma";
$dbpass = "darksigma";
$dbname = "Eminsm_sigma";


?>
