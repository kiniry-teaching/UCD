<?php
//Authoer: OisinMcD
//closes the connection to the databasae
mysql_close($connection);
?>



