<?php
//Authoer: OisinMcD
$connection = mysql_connect($dbhost, $dbuser, $dbpass);
if (!$connection) {
    die('Could not connect: ' . mysql_error());
}

$db = mysql_select_db($dbname, $connection);

?>
