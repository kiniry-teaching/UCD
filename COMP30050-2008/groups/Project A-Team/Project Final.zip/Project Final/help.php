<?php
   /*Author: Sean Tracey, Alan McPhilips */

//Determine if the sumbit button has been clicked. If so, begin validating form data.
   
  if ($_POST['submitB'] == "Submit")
  {
     //Determine if a Name was entered
     
		$valid_form = true;
     
		if ($_POST['name'] == "")
		{
			echo "Enter your name";
			$valid_form = false;
		}
		
		else
		{
			$name = $_POST['name'];
		}
		
		if ($_POST['uname'] == "")
		{
			echo "Enter a user name";
			$valid_form = false;
		}
		
		else
		{
			$username = $_POST['uname'];
		}
		
		if ($_POST['pass'] == "")
		{
		
			echo "Enter a password";
			$valid_form = false;
		
		}
		
		elseif (strlen($_POST['pass']) < 4)
		{
			
			echo "Password must contain at least 4 characters";
			$valid_form = false;
		}
		
		else
		{
			$password = $_POST['pass'];
		}
		
		
		//if all form fields were submitted properly, begin processing
		
		if($valid_form == true)
		{
		
			//form processing code goes here
		
		}
  }
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD/XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml11-transitional.dtd">
<!-- Author: Sean Tracey, Alan McPhilips --> 
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <title>A Web Page</title>
</head>
<body>

<form method="post" action="welcome.php"/>
Enter Name: <input type="text" name="name"/>
Enter user name: <input type="text" name="uname"/>
Enter Password (must contain at least 6 characters): <input type="password" name="pass"/>
<input type="submit" name="submitB" value="Submit"/>
</form>

</body>
</html>



