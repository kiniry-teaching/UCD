<html>
<!-- Author: Sean Tracey, Alan McPhilips --> 

<head>


<title>:nav:</title>


</head>
<body bgcolor= "black">
<table width="100%">

<h1><font size= "3", color="white">Navigation</font>
</h1>

<font size = "4">

<p>
<a href ="home.php" target = "linkage">Home</a>
<br/>
<p>
<a href ="mypage.php" target = "linkage">Place Your Bets!</a>
<br/>
<p>
<a href ="results.php" target = "linkage">Results</a>
<br/>
<p>
<a href ="account.php" target = "linkage">Account Information<a/>
<br/>
<p>
<a href ="leaderboard.php" target = "linkage">League Table</a>
<br/>
<p>
<a href ="bye.php" target = "linkage">Logout</a>
<br/>
<p>
<a href ="aboutus.php" target = "linkage">About Us</a>
</p>
</font>

</body>
</html>

