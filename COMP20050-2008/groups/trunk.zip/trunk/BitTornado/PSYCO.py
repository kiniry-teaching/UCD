# edit this file to enable/disable Psyco
# psyco = 1 -- enabled
# psyco = 0 -- disabled

psyco = 0
