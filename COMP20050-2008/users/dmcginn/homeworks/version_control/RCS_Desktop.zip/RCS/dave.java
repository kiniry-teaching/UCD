class Dave {
	public static void main(String[] args) {
		System.out.print("My name is Dave");
	}

}
