/* A Hello, World program, by $Author: jkiniry $ */

#include <stdio.h>

static char rcsid[] = "$Id: RCS_Experimentation.tar 2488 2005-02-14 21:40:27Z jkiniry $";

int main(int argc, char **argv) {
  printf("Hello, 