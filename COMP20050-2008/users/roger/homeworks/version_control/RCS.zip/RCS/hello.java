//$Id: hello,v 1.1 2008/02/25 16:14:13 roger Exp roger $
public class hello {
	public static void main (String args[]) {
		
		String readout = "Hello there, this is a simple java program to test a java file using RCS and the id marker";
		
		System.out.println(readout);

		System.exit(0);
	}
}

