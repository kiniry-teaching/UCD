/*
 * The KindSoftware Connector Architecture, Version 0.1
 *
 * Copyright (C) 1999-2001 by KindSoftware, LLC.  All rights reserved.
 *
 * $Id: Component.java 2105 2002-12-29 12:29:18Z kiniry $
 */

package com.kindsoftware.connector;

/**
 * A component is a major part of the system that will be used
 * compositionally and composed via connectors.
 *
 * Bandwidth is specified in kilobytes per second (kB/sec).
 * Latency is specified in milliseconds (ms).
 *
 * @version $Revision: 2105 $ $Date: 2002-12-29 12:29:18 +0000 (Sun, 29 Dec 2002) $
 * @author Joseph Kiniry <kiniry@kindsoftware.com>
 *
 * @bon A major part of the system that will be used compositionally
 * and composed via connectors.
 *
 * @todo Convert english invariants into proper specification.
 * @invariant The components associated with a connector are exactly the
 * connector associated with the components.
 * @invariant All references attributes non-null.
 * @concurrency (CONCURRENT) All methods are fully concurrent.
 * @see Connector.txt See Connector system overview for details on interfaces,
 * levels, etc.
 **/

public abstract class Component extends Object
{
  // Attributes

  /**
   * The connectors associated with this component.  This Hashtable is keyed
   * on interface names (a String) and contains instances of Connector (or a
   * subclass).
   * @invariant (forall i in connectors.values() : i <: Connector)
   * @invariant (forall i in connectors.keys() : i : String)
   * @see java.lang.String
   * @see Connector
   **/
  protected Hashtable connectors;

  /**
   * An association between connectors and levels.  This Hashtable is hashed
   * on instances of Connector and stores Vectors of Integer objects.
   * @invariant (forall i in levels.keys() : i <: Connector)
   * @invariant (forall i in levels.values() : i : Vector and 
   *             forall j in i : j : Integer)
   * @invariant (forall i in level.keys() : i in connectors.values())
   * @see java.lang.Integer
   * @see java.util.Vector
   * @see Connector
   **/
  protected Hashtable levels;

  /**
   * A cached value of the maximum level of <em>any</em> connector.
   * @invariant (maxLevel == max(forall i : level.values()))
   **/
  protected int maxLevel;

  /**
   * A cached set of values of the maximum level of each connector of this
   * connector.  The keys of this Hashtable are Connector instances and the
   * values are instances of Integer.
   * @invariant (forall i in maxLevels.keys() : i <: Connector)
   * @invariant (forall i in maxLevels.values() : i : Integer)
   * @invariant (forall i in maxLevels.keys() : i in connectors.values())
   * @invariant (forall i in maxLevels.values() : 
   *                    i == max(forall i : level.values()))
   * @see java.lang.Integer
   * @see Connector
   **/
  protected Hashtable maxLevels;

  /**
   * The bandwidth communication demands this component makes on a connector
   * at each level.  This Hashtable is keyed on instances of Connector and
   * contains arrays of floats.
   * @todo Refactor this information/data structure into a new class.
   * @invariant (forall i in levels.values() : 
   *             exists j in bandwidthRequirements : j[i] is defined)
   * @invariant (forall i in levels.values() : 
   *             forall j in i.length() : 
   *             bandwidthRequirements[i] >= 0.0)
   * @see Connector
   **/
  protected Hashtable bandwidthRequirements;

  /**
   * The latency communication demands this component makes on a connector at
   * each level.  This Hashtable is keyed on instances of Connector and
   * contains arrays of floats.
   * @invariant (forall i in levels.values() : exists latencyRequirements[i])
   * @invariant (forall i in latencyRequirements.length() : 
   *             latencyRequirements[i] >= 0.0)
   * @see Connector
   **/
  protected Hashtable latencyRequirements;

  /**
   * A flag that indicates if a component is ready to have its connnectors
   * manipulated.
   * @modifies (SINGLE-ASSIGNMENT) Once this variable goes true it remains true.
   **/
  protected boolean isReady = false;

  /**
   * The interfaces that this component needs to operate.  This Vector
   * contains instances of Interface.
   * @see Interface
   * @invariant (forall i in interfaceRequires : i : Interface)
   **/
  protected Vector interfaceRequires;

  /**
   * The interfaces that this component provides.  This Vector contains
   * instances of Interface.
   * @see Interface
   * @invariant (forall i in interfaceProvides : i : Interface)
   **/
  protected Vector interfaceProvides;

  // Inherited Methods

  /**
   * The default behavior of the following methods is correct:
   *
   * protected Object clone()
   * boolean equals(Object obj)
   * protected void finalize()
   * int hashCode()
   **/

  /**
   * @return a decent, parsable string representation of the component.
   * @pre -- none
   * @post (Result != null)
   * @todo Design this representation.
   **/
  public String toString();
  
  // Constructors

  // no default constructor is provided.

  // Public

  /**
   * Return the connectors currently associated with this component.  Note
   * that, because Component is a concurrent class, this snapshot is
   * necessarily old and possibly out-of-date by the time the client is able
   * to investigate it.
   *
   * @bon What connectors are associated with this component?
   * @design Note that, because Component is a concurrent class, this snapshot
   * is necessarily old and possibly out-of-date by the time the client is able
   * to investigate it.
   * @pre (isReady())
   * @modifies (QUERY)
   * @ensures Result is an Enumeration snapshot of connectors.
   * @concurrency (GUARDED) - We wish to make sure that when building the
   * Enumeration the state of the connectors of the component does not change.
   * @return the connectors currently associated with this component.
   **/
  public abstract synchronized Enumeration connectors();

  /**
   * Returns a Hashtable that associates connectors to levels.  This Hashtable
   * is hashed on instances of Connector and stores Vectors of Integer objects.
   *
   * @bon What levels are associated with the connectors of this
   * component?
   * @pre (isReady())
   * @post (Result.equals(levels))
   * @modifies (QUERY)
   * @return a Hashtable that associates connectors to levels.  This Hashtable
   * is hashed on instances of Connector and stores Integer objects.
   **/
  public abstract Hashtable levels();

  /**
   * @bon What is the maximum level associated with any connector of this
   * component?
   * @todo joe - We might not need this method at all; reevaluate a bit later
   * to see if we can remove it entirely.
   * @pre (isReady())
   * @post (Result == maxLevel)
   * @modifies (QUERY)
   * @return the maximum level associated with any connector.
   * @review kiniry - Return type of this and related level methods must be
   * the same as the level type in SDO.
   * @see SDO#getlevel
   **/
  public abstract int maxLevel();

  /**
   * @bon What is the maximum level associated with a connector of this
   * component?
   * @pre ((connector != null) && isReady())
   * @post (Result == maxLevels.get(connector))
   * @modifies (QUERY)
   * @param connector the connector we are interested in.
   * @return the maximum level of the connector.
   * @review kiniry - Return type of this and related level methods must be
   * the same as the level type in SDO.
   * @see SDO#getlevel
   **/
  public abstract int maxLevel(Connector connector);

  /**
   * Returns an array that associates, for the given connector, each level
   * defined on the connector with a bandwidth demand.
   *
   * @bon What bandwidth communication demands does this component make on a
   * connector at each level?
   * @design Bandwidth is specified in kilobytes per second (kB/sec).
   * @pre ((connector != null) && isReady())
   * @post (Result.equals(bandwidthRequirements))
   * @modifies (QUERY)
   * @param connector the connector we are interested in.
   * @return an array that associates, for the given connector, each level
   * defined on the connector with a bandwidth demand.
   **/
  public abstract float[] bandwidthRequirements(Connector connector);

  /**
   * Returns an array that associates, for the given connector, each level
   * defined on the connector with a latency requirement.
   *
   * @bon What latency communication demands does this component make on a
   * connector at each level?
   * @design Latency is specified in milliseconds (ms).
   * @pre ((connector != null) && isReady())
   * @post (Result.equals(latencyRequirements))
   * @modifies (QUERY)
   * @param connector the connector we are interested in.
   * @return an array that associates, for the given connector, each level
   * defined on the connector with a latency requirement.
   **/
  public abstract float[] latencyRequirements(Connector connector);

  /**
   * @bon Is this component ready to be queried and have its connectors
   * manipulated?
   * @pre -- none
   * @ensures (isReady() implies isReady().stable) - Once isReady() goes to
   * true, it remains true.
   * @modifies (QUERY)
   * @return a flag that indicates if this component is ready to have its
   * connectors manipulated.
   **/
  public abstract boolean isReady();

  /**
   * @bon What interfaces does this component need?
   * @pre -- none
   * @post (Result.equals(interfaceRequires))
   * @modifies (QUERY)
   * @return the interfaces that this component needs to operate.
   **/
  public abstract Enumeration interfaceRequires();

  /**
   * @bon What are the interfaces that this component provides?
   * @pre -- none
   * @post (Result.equals(interfaceProvides))
   * @modifies (QUERY)
   * @return the interfaces that this component provides.
   **/
  public abstract Enumeration interfaceProvides();

  /**
   * Add a connector to the set of connectors through which this
   * component communicates.  If interface is already bound to a connector,
   * replace it with the new connector.  If the new and old connectors are the
   * same, do nothing.
   *
   * @bon Add a connector to the set of connectors through which this
   * component communicates.
   * @pre ((connector != null) && (interface != null))
   * @pre (exists s in connectors.keys() : s.equals(interface))
   * @post (connectors.get(interface).equals(connector))
   * @modifies connectors
   * @concurrency (GUARDED) - We wish to make sure that when building the
   * Enumeration the state of the connectors of the component does not change.
   **/
  public abstract synchronized void 
    bindConnector(Connector connector, String interface);

  /**
   * Remove a connector from the set of connectors through which this
   * component communicates.  If the parameter is not currently bound
   * connector, do nothing.
   *
   * @bon Remove a connector from the set of connectors through which this
   * component communicates.
   * @pre (connector != null)
   * @post (not connector in connectors.values())
   * @param connector the connector to remove.
   * @modifies connectors
   * @concurrency (GUARDED) - We wish to make sure that when building the
   * Enumeration the state of the connectors of the component does not change.
   **/
  public abstract synchronized void unbindConnector(Connector connector);

  /**
   * @bon Initialize this component so that it is prepared for being
   * queried and having connectors manipulated.
   * @pre -- none
   * @post -- none
   * @ensures (initialize() leadsto isReady()) - After calling initialize(), a
   * component will become ready in a finite amount of time.
   **/
  public abstract void initialize();

  // Protected Methods
  // Package Methods
  // Private Methods
}
// end of class Component
