/*
 * The KindSoftware Connector Architecture, Version 0.1
 *
 * Copyright (C) 1999-2001 by KindSoftware, LLC.  All rights reserved.
 *
 * $Id: ChannelInformation.java 2105 2002-12-29 12:29:18Z kiniry $
 */

package com.kindsoftware.connector;

/**
 * <p> ChannelInformation describes the capabilities of a channel. </p>
 *
 * @see Connector.txt
 *
 * @version $Revision: 2105 $ $Date: 2002-12-29 12:29:18 +0000 (Sun, 29 Dec 2002) $
 * @author Joseph Kiniry <kiniry@kindsoftware.com>
 * @bon Describes the capabilities of a channel.
 *
 * @todo kiniry - Convert any english invariants into predicates.
 * @review kiniry - Is a specification of latency in ms sufficient resolution
 * for our needs?  Should we use us instead?  (i.e. microseconds)
 *
 * @invariant (maxRate >= 0) && (averageRate >= 0) && 
 *            (minLatency >= 0) && (averageLatency >= 0) && 
 *            (identifier != null)
 * @invariant (maxRate >= averageRate) - Set reasonability bounds on averages.
 * @invariant (minLatency <= averageLatency) - Set reasonability bounds on
 * averages.
 * @invariant Identifiers are unique per channel type.
 *
 * @concurrency (QUERY)
 **/

public class ChannelInformation extends Object implements Serializable
{
  // Attributes

  /**
   * The maximal data rate of the channel (in kilobytes per second).
   **/
  private float maxRate;

  /**
   * The average data rate of the channel (in kilobytes per second).
   **/
  private float averageRate;

  /**
   * The minimal latency of the channel (in milliseconds).
   **/
  private float minLatency;

  /**
   * The average latency of the channel (in milliseconds).
   **/
  private float averageLatency;

  /**
   * An identifier for this channel type.
   **/
  private String identifier;

  // Inherited Methods

  /**
   * The default implementations of the following methods are correct:
   *
   * protected Object clone()
   * protected void finalize()
   * int hashCode()
   **/

  /**
   * @bon Is this object equal to another?
   * @pre (obj != null)
   * @post ((maxRate == obj.maxRate) && (averageRate == obj.averageRate) && 
   *        (minLatency == obj.minLatency) && (averageLatency == obj.averageLatency) && 
   *        (identifier.equals(obj.identifier))
   * @return a boolean flag indicating if the two objects are equal.
   **/
  public boolean equals(Object obj);

  /**
   * @bon What is a printable string form for this data?
   * @pre -- none
   * @ensures Result is a string of the following form:
   * "Channel <identifier>: <averageRate>/<maxRate> kb/s <variable size
   * padding> <averageLatency>/<minLatency> ms"
   * @return a printable string form for this data.
   **/
  public String toString();

  // Constructors

  /**
   * @param mRate the maximal data rate of the channel (in kilobytes per
   * second).
   * @param aRate the average data rate of the channel (in kilobytes per
   * second). 
   * @param mLatency the minimal latency of the channel (in milliseconds).
   * @param aLatency the average latency of the channel (in milliseconds).
   * @param id an identifier for this channel type.
   * @pre (id != null)
   * @post ((maxRate == mRate) && (averageRate == aRate) &&
   *        (minLatency == mLatency) && (averageLatency == aLatency) &&
   *        identifier.equals(id))
   **/
  ChannelInformation(float mRate, float aRate, 
		     float mLatency, float aLatency,
		     String id)

  // Public Methods

  /**
   * @bon What is the maximal data rate of the channel (in kilobytes per
   * second)?
   * @pre -- none
   * @post (Result == maxRate)
   * @return the maximal data rate of the channel (in kilobytes per second).
   **/
  public float getMaxRate();

  /**
   * @bon What is the average data rate of the channel (in kilobytes per
   * second)?
   * @pre -- none
   * @post (Result == averageRate)
   * @return the average data rate of the channel (in kilobytes per second).
   **/
  public float getAverageRate();

  /**
   * @bon What is the minimal latency of the channel (in milliseconds)?
   * @pre -- none
   * @post (Result == minLatency)
   * @return the minimal latency of the channel (in milliseconds).
   **/
  public float getMinLatency();

  /**
   * @bon What is the average latency of the channel (in milliseconds)?
   * @pre -- none
   * @post (Result == averageLatency)
   * @return the average latency of the channel (in milliseconds).
   **/
  public float getAverageLatency();

  /**
   * @bon What is the identifier for this channel type?
   * @pre -- none
   * @post (Result == identifier)
   * @return the identifier for this channel type.
   **/
  public String getIdentifier();

  // Protected Methods
  // Package Methods
  // Private Methods
}
// end of class ChannelInformation
