/*
 * The KindSoftware Connector Architecture, Version 0.1
 *
 * Copyright (C) 1999-2001 by KindSoftware, LLC.  All rights reserved.
 *
 * $Id: Manager.java 2105 2002-12-29 12:29:18Z kiniry $
 */

package com.kindsoftware.connector;

/**
 * @bon Manages the set of all connectors in a VM.
 *
 * @version $Revision: 2105 $ $Date: 2002-12-29 12:29:18 +0000 (Sun, 29 Dec 2002) $
 * @author Joseph Kiniry <kiniry@kindsoftware.com>
 * @invariant All references attributes non-null.
 **/

public abstract class Manager extends Object
{
  // Attributes

  /**
   * The connectors currently in use by this manager.
   **/
  private Vector connectors;

  /**
   * The component currently known/in use by this manager.
   **/
  private Vector components;

  /**
   * The channels currently known/in use by this manager.
   **/
  private Vector channels;

  // Inherited Methods

  /**
   * The default behavior of the following methods is correct:
   *
   * protected Object clone()
   * boolean equals(Object obj)
   * protected void finalize()
   * int hashCode()
   **/
  
  /**
   * @return a decent, parsable string representation of the state of this
   * manager.
   * @pre -- none
   * @post (Result != null)
   * @todo Design this representation.
   **/
  public String toString();

  // Constructors

  /**
   * This is a default constructor. It does nothing of consequence.
   **/

  public Manager();

  // Public Methods

  /**
   * @bon What are the connectors currently in use?
   * @modifies (QUERY)
   * @pre -- none
   * @post (Result.equals(connectors))
   * @return a list of the connectors currently in use.
   **/
  public Enumeration connectors();
  
  /**
   * @bon What components are available?
   * @modifies (QUERY)
   * @pre -- none
   * @post (Result.equals(components))
   * @return a list of components currently registered.
   **/
  public Enumeration components();
  
  /**
   * @bon What channel types are available?
   * @modifies (QUERY)
   * @pre -- none
   * @post (Result.equals(channels))
   * @return a list of the channels currently available.
   **/
  public Enumeration channels();
  
  /**
   * @bon How many channel types are available?
   * @modifies (QUERY)
   * @pre -- none
   * @post (Result == channels.size())
   * @return the number of channels currently available.
   **/
  public int numberOfChannels();

  /**
   * @bon Is a particular channel type currently available? 
   * @modifies (QUERY)
   * @pre (channelType != null)
   * @post (Result == (exists i in channels : i.channelIdentifier()))
   * @return a flag indicating if the given channel type is available.
   **/
  public boolean channelAvailable(String channelType);

  /**
   * @bon Initialize the Connector system.
   * @pre -- none
   * @post -- none
   **/
  public void initialize();
  
  /**
   * @bon Perform an orderly/immediate shutdown all connectors.
   * @pre -- none
   * @post -- none
   **/
  public void shutdown();
  
  /**
   * @bon Perform an orderly/immediate shutdown of a specific connector.
   * @pre -- none
   * @post -- none
   **/
  public void shutdown(Connector connector);
  
  /**
   * @bon Register a component with the manager.
   * @pre (component != null)
   * @post (component in components)
   **/
  public void register(Component component);

  /**
   * @bon Unregister a component with the manager.
   * @pre (component != null)
   * @post (not component in components)
   **/
  public void unregister(Component component);
  
  /**
   * @bon Compose a set of components.
   * @pre (components != null)
   * @post -- none
   **/
  public void compose(Vector components);

  // Protected Methods
  // Package Methods
  // Private Methods
}
// end of class Manager
