/*
 * The KindSoftware Connector Architecture, Version 0.1
 *
 * Copyright (C) 1999-2001 by KindSoftware, LLC.  All rights reserved.
 *
 * $Id: SDO.java 2105 2002-12-29 12:29:18Z kiniry $
 */

package com.kindsoftware.connector;

/**
 * <p> A Semantic Data Object, the primary means by which components
 * communicate with each other.  String "tags" are multimapped to integer
 * "levels" and Serializable "values". </p>
 *
 * <p> Tags (synonymous with properties, but we are using the standard SDO
 * nomenclature) are Strings, or more properly, a "valid" subset of strings to
 * assist with debugging, monitoring, and maintaining communication systems
 * based upon the connector package.  There is little/nothing to be gained in
 * permitting non-simple strings for tags, so we disallow them. </p>
 *
 * <p> Levels are using during multi-resolution communiction as specified in
 * the Connector System design document.  Briefly, when two components
 * communicate, each is capable of using a certain "level" of data.  All data
 * above that level is useless.  We use integers as level indicators because
 * they are a total ordered set/lattice, are discrete, and easy to understand,
 * sort, etc. </p>
 *
 * <p> Type information is automatically added to an entry via reflection in
 * the Java implementation of SDO.  When a non-Java SDO is constructed
 * (perhaps in a C++ class) a level tag is automatically added to the data
 * during a put() and, if the data is a basic type, it's representation is
 * massaged in such a way that it is processable on the opposite side by a
 * Java implementation. </p>
 * 
 * <p> In general, for full multi-platform compatibility, only basic types
 * encoded as basic strings are utilized.  While inefficient, it is excellent
 * for system testing and debugging. </p>
 *
 * <p> Putting a SDO inside of an SDO is a "part-of" operation, not a "union"
 * operation.  Thus, a query for a tag in the "put" SDO that is not in the
 * enclosing SDO will return null.  The semantics of size is as expected, the
 * total size of the new SDO is at least the sum of the size of the original
 * plus the size of the "put" SDO. </p>
 *
 * @see Connector.txt
 *
 * @version $Revision: 2105 $ $Date: 2002-12-29 12:29:18 +0000 (Sun, 29 Dec 2002) $
 * @author Joseph Kiniry <kiniry@kindsoftware.com>
 * @bon Semantic Data Object
 *
 * @invariant All tags must be valid.
 * @invariant All used tags has been added but not deleted. No two tags can
 * be the same. 
 * @invariant A valid tag is a non-null String.
 * @invariant The size of an SDO is exactly the sum of the sizes of its
 * (Tag,Level,Data) triples. 
 * @invariant The number of entries in an SDO is exactly the number of tags
 * in its tag set.
 * @todo kiniry - Convert these english invariants into predicates.
 * @todo kiniry - Consider a switch of int to short or even byte for levels.
 *
 * @concurrency (GUARDED) All data is stored in a java.util.Hashtable and
 * Hashtable is fully synchronized, thus this class is synchronized by
 * default.
 * @review kiniry - Currently all methods use Serializable as the parameter.
 * I don't know how this jives with the messaging system or persistence right
 * now.
 * @review kiniry - Currently this class extends Dictionary but there are
 * likely more appropriate, "modern" classes in the Collections stuff.  The
 * choice will be made at implementation-time depending upon final JDK
 * target-version choices and similar.
 * @review kiniry - There are two put methods because the semantics of putting
 * an SDO inside of an SDO are non-trivial and certain optimizations can be
 * made for such.  Reconsider this decision after review.
 *
 * @design A tag is considered "valid" iff it (a) is non-null and (b) contains
 * only characters in the range 32-128 ASCII (standard printable characters,
 * no accents, no UNICODE, etc.).  We state these constraints to ensure simple
 * multi-interface debugging (i.e. one must be able to print/understand tags
 * even on an ancient vt100) and efficient encoding (no need to deal with
 * special cases).
 * @design A level is considered "valid" iff it is greater than or equal to
 * 0.  I.e. For_all level : level >= 0.  Levels have no upper bound (except
 * MAXINT).
 **/

public abstract class SDO extends Dictionary implements Serializable
{
  // Attributes

  /**
   * Contains all of the data for the SDO.
   *
   * @todo kiniry - We would really prefer a multimap class given every tag
   * has a level, type, and a value associated with it.  We'll likely have to
   * use a supplimentary "value" class to encapsulate these three pieces of
   * data.  That class might be an inner class. (TBD)
   **/
  private Hashtable data;

  // Inherited Methods

  /**
   * Also, take time to consider if the default behavior of the
   * standard methods of java.lang.Object are what you want for this
   * class.  
   *
   * Those methods are:
   * protected Object clone()
   * boolean equals(Object obj)
   * protected void finalize()
   * int hashCode()
   * String toString()
   *
   * @todo kiniry - On first pass, it looks like clone, equals, and toString
   * should be specified.
   **/

  // Constructors

  /**
   * This is a default constructor. It does nothing of consequence.
   * @pre -- none
   * @post (data != null)
   **/
  public SDO();

  // Public Methods

  /**
   * @bon What data/SDO is associated with a given Tag?
   * @modifies (QUERY)
   * @param tag a tag.
   * @pre (isValidTag(tag))
   * @ensures if put(t,l,v) has taken place and a remove(t) has not and t ==
   * tag, then Result == v.
   **/
  public Serializable get(String tag);

  /**
   * @bon What level is associated with a given Tag?
   * @modifies (QUERY)
   * @param tag a tag.
   * @return the level associated with the specified tag.
   * @pre (isValidTag(tag))
   * @ensures if put(t,l,v) has taken place and a remove(t) has not and t ==
   * tag, then Result == l.
   **/
  public int getLevel(String tag);

  /**
   * @bon Is a given tag valid?
   * @modifies (QUERY)
   * @param tag a tag.
   * @return a flag indicating if the tag is valid.
   * @pre -- none
   * @ensures Result iff tag is valid.
   * @see SDO Tag validity is defined in the SDO class header.
   **/
  public boolean isValidTag(String tag);

  /**
   * @bon Is a given level valid?
   * @modifies (QUERY)
   * @param level
   * @return a flag indicating if the level is valid.
   * @pre -- none
   * @ensures Result iff level is valid.
   * @see SDO Level validity is defined in the SDO class header.
   **/
  public boolean isValidLevel(int level);
  
  /**
   * @bon Is a given tag used?
   * @modifies (QUERY)
   * @param tag a tag.
   * @return a flag indicating if this SDO has a value associated with the
   * specified tag.
   * @pre (isValidTag(tag))
   * @ensures Result iff put(t,l,v) has taken place and a remove(t) has not
   * and t == tag
   **/
  public boolean containsTag(String tag);

  /**
   * @bon Does this SDO contain at least one tag of a specified level?
   * @modifies (QUERY)
   * @param level
   * @return a flag indicating if this SDO has at elast one tag of the
   * specified level.
   * @pre (isValidLevel(level))
   * @ensures Result iff at least one put(t,l,v) has taken place and a
   * remove(t) has not where l >= level.
   * @design Note that this comparison is >= while the ones associated with
   * deleteAbove() and deleteBelow() are non-inclusive.
   **/
  public boolean containsLevel(int level);
  
  /**
   * @bon What is the current size?
   * @return the size of the current SDO in bytes.
   * @modifies (QUERY)
   * @pre -- none
   * @post (Result >= 0)
   **/
  public long serializedSize();
  
  /**
   * @bon What is the current tag set?
   * @modifies (QUERY)
   * @return an enumeration of tags (Strings), one for each tag in the SDO.
   * @pre -- none
   * @ensures For all triples in this SDO, each triple's tag will be included
   * in the result Enumeration.
   **/
  public Enumeration tags();

  /**
   * @bon What is the current value set?
   * @modifies (QUERY)
   * @return an enumeration of values (Serializables), one for each value in
   * the SDO, whether it was input as an SDO or not.
   * @pre -- none
   * @ensures For all triples in this SDO, each triple's value will be included
   * in the result Enumeration.
   **/
  public Enumeration elements();
  
  /**
   * @bon How many entries (triples) exist?
   * @modifies (QUERY)
   * @return the total number of entries in this SDO.
   * @pre -- none
   * @post (Result >= 0)
   **/
  public int size();
  
  /**
   * @bon What is the type of the data associated with a Tag?
   * @modifies (QUERY)
   * @param tag a tag.
   * @return a string representation of the type of the data associated with
   * the specified tag.  If this string is of the proper form, (i.e. full Java
   * classname), it can be used via reflection to construct a Java class that
   * can contain the data value without loss of information.
   * @pre (isValidTag(tag))
   * @post (Result != null)
   **/
  public String type(String tag);
  
  /**
   * @bon Add/replace (Tag,Level,Data) triple.
   * @modifies (data)
   * @param tag a tag.
   * @param level a level.
   * @param value a data value.
   * @pre (isValidTag(tag) && isValidLevel(level) && (value != null))
   * @ensures If the specified tag has not been used, value is returned.
   * Otherwise, the previous value associated with the tag is returned.
   **/
  public Serializable put(String tag, int level, Serializable value);

  /**
   * @bon Add/replace (Tag,Level,SDO) triple.
   * @modifies (data)
   * @param tag a tag.
   * @param level a level.
   * @param sdo an SDO.
   * @pre (isValidTag(tag) && isValidLevel(level) && (sdo != null))
   * @ensures If the specified tag has not been used, value is returned.
   * Otherwise, the previous value associated with the tag is returned.
   **/
  public Serializable put(String tag, int level, SDO sdo);

  /**
   * @bon Delete a triple based upon a Tag.
   * @modifies (data)
   * @param tag a tag.
   * @pre (isValidTag(tag))
   * @post (get(tag) == null)
   * @ensures If the specified tag has not been used, a null is returned.
   * Otherwise, the previous value associated with the tag is returned.
   **/
  public Serializable remove(String tag);
  
  /**
   * @bon Delete all triples above a certain level.
   * @modifies (data)
   * @param level the level above which we delete.
   * @return the number of triples deleted from the SDO.
   * @pre (isValidLevel(level))
   * @ensures All triples with associated levels > level are removed from the
   * SDO.
   **/
  public int deleteAbove(int level);
  
  /**
   * @bon Delete all triples below a certain level.
   * @modifies (data)
   * @param level the level below which we delete.
   * @return the number of triples deleted from the SDO.
   * @pre (isValidLevel(level))
   * @ensures All triples with associated levels < level are removed from the
   * SDO.
   **/
  public int deleteBelow(int level);

  // Protected Methods
  // Package Methods
  // Private Methods
}
// end of class SDO
