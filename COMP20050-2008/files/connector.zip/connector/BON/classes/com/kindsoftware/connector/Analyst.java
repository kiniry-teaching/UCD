/*
 * The KindSoftware Connector Architecture, Version 0.1
 *
 * Copyright (C) 1999-2001 by KindSoftware, LLC.  All rights reserved.
 *
 * $Id: Analyst.java 2105 2002-12-29 12:29:18Z kiniry $
 */

package com.kindsoftware.connector;

/**
 * Aggregate data and associated analysis of channel availability and
 * conditions.
 *
 * @version $Revision: 2105 $ $Date: 2002-12-29 12:29:18 +0000 (Sun, 29 Dec 2002) $
 * @author Joseph Kiniry <kiniry@kindsoftware.com>
 *
 * @invariant All channel types are exactly one of the set of types specified
 * in the CHANNEL class.
 * @concurrency (CONCURRENT) All methods of this class are fully concurrent.
 * @design Note that the analyst only controls and collects information
 * associated with a particular channel <EM>type</EM>, not a specific connector
 * instance.  I.e. This class collects data about communication performance
 * over a particular medium (say, Java data streams or shared records in a
 * database).  See the Channel class for more information.
 *
 * @see com.kindsoftware.connector.Channel
 **/

public abstract class JavadocClass extends Object
{

  // Attributes

  /**
   * <P> A set of flags, one per channel type, indicating if data collection
   * is enabled. </P>
   **/
  private boolean [] dataCollectionEnabled;

  /**
   * <P> The set of data statistics gathered by the Analyst component, one
   * statistic per channel type.  Each entry in this table is a Vector of
   * ChannelInformation objects. </P>
   **/
  private Vector [] channelData;

  // Inherited Methods

  /**
   * The following inherited methods do not need to be redefined for this
   * class.
   *
   * Those methods are:
   * protected Object clone()
   * boolean equals(Object obj)
   * protected void finalize()
   * int hashCode()
   **/

  /**
   * @return a report on the current state of the Analyst.
   * @pre -- none
   * @post (Result != null)
   **/

  public String toString();

  // Constructors

  /**
   * Initializes an Analyst object to prepare for data collection an
   * analysis.
   **/

  public Analyst();

  // Public Methods

  /**
   * <P> Query for the information that has been collected about a particular
   * channel type. </P>
   *
   * @bon What is the current information available for a particular channel
   * type?
   * @param channelType the type of channel we are querying about.  Channel
   * types are identified in the Channel class.
   * @return an Enumeration of ChannelInforamtion objects.
   *
   * @see com.kindsoftware.connector.Channel
   * @see com.kindsoftware.connector.ChannelInformation
   * @see idebug.Statistic
   *
   * @pre (channelType in Channel.legalChannelTypes())
   * @post (Result != null)
   * @ensures Result is an Enumeration of ChannelInformation objects.  Not
   * every identified ChannelInformation will be part of this enumeration
   * since some types of data might not have sufficient data points to return
   * any reasonable information.
   **/
  public Enumeration currentInfo(int channelType);

  /**
   * @bon Start gathering data on a particular channel type.
   * @param channelType the type of channel we are querying about.  Channel
   * types are identified in the Channel class.
   * @pre (channelType in Channel.legalChannelTypes())
   * @post -- none
   * @ensures Data is being collected on the specified channel type, whether
   * it is currently known or introduced in the future.
   **/
  public void startDataCollection(int channelType);

  /**
   * @bon Stop gathering data on a particular channel type.
   * @param channelType the type of channel we are querying about.  Channel
   * types are identified in the Channel class.
   * @pre (channelType in Channel.legalChannelTypes())
   * @post -- none
   * @ensures Data is not being collected on the specified channel type,
   * whether it is currently known or introduced in the future.
   **/
  public void stopDataCollection(int channelType);

  /**
   * @bon Start gathering data on all channel types.
   * @pre -- none
   * @post -- none
   * @ensures Data is being collected on all channel types currently known or
   * introduced in the future.
   **/
  public void startAllDataCollection();

  /**
   * @bon Stop gathering data on all channel types.
   * @pre -- none
   * @post -- none
   * @ensures Data is not being collected on all channel types currently known
   * or introduced in the future.
   **/
  public void stopAllDataCollection();  

  // Protected Methods
  // Package Methods
  // Private Methods
}
// end of class Analyst
