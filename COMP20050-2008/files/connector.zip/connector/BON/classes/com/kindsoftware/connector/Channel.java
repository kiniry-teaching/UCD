/*
 * The KindSoftware Connector Architecture, Version 0.1
 *
 * Copyright (C) 1999-2001 by KindSoftware, LLC.  All rights reserved.
 *
 * $Id: Channel.java 2105 2002-12-29 12:29:18Z kiniry $
 */

package com.kindsoftware.connector;

/**
 * <P> Channels are the potential communication mediums for connectors.
 * Architypical communication channels include shared memory, shared data
 * files, a network connection, etc. </p>
 *
 * <P> Channels are independent communication mechanism, thus two channels
 * might use the exact same communication mechanism but have radically
 * different behavior or capabilities.  A classic example of this is a
 * computer using an Ethernet port and a wireless card for TCP/IP
 * connectivity.  These two communication substrates are <EM>different</EM>
 * channel types. </P>
 *
 * <P> New channel types are implemented as subclasses of Channel.  At system
 * initialization time or whenever a new channel becomes available, every
 * channel class is initialized, detects whether that particular channel type
 * is available, and registers/unregisters itself appropriately. </P>
 *
 * <P> This class is just the common interface to the core Channel methods and
 * contains the code to manage channel registration, current information, etc.
 * </P>
 *
 * @see Connector.txt
 *
 * @version $Revision: 2105 $ $Date: 2002-12-29 12:29:18 +0000 (Sun, 29 Dec 2002) $
 * @author Joseph Kiniry <kiniry@kindsoftware.com>
 * @bon A potential communication medium for connectors.
 *
 * @invariant All types mentioned are elements of the legal channel types set.
 * @todo kiniry - Convert these english invariants into predicates.
 *
 * @concurrency (GUARDED) All methods on Channel are synchronized for your
 * protection.
 **/

public abstract class Channel extends Object
{
  // Attributes

  /**
   * The communication properties of this channel.
   **/
  protected ChannelInformation properties;

  /**
   * The current state of this channel.
   **/
  protected ChannelInformation state;

  /**
   * A list of connectors using this channel.
   **/
  protected Enumeration connectors;

  /**
   * A list of the valid channel that exist at this instant in time.
   **/
  private static Enumeration channels;

  /**
   * A flag indicating if this channel is available.
   **/
  private boolean enabled = true;

  /**
   * A list of all the channel types identified in the Connector system.
   **/
  private int nullChannel = 0;
  private int streamChannel = 1;
  private int fileChannel = 2;
  private int relationalDatabaseChannel = 3;
  private int namedPipeChannel = 4;
  private int messagingChannel = 5;
  private int tupleSpaceChannel = 6;
  private int rmiChannel = 7;
  private int jmsChannel = 8;
  private int objectDatabaseChannel = 9;
  private int loopbackChannel = 10;

  // Inherited Methods

  /**
   * Also, take time to consider if the default behavior of the
   * standard methods of java.lang.Object are what you want for this
   * class.  
   *
   * Those methods are:
   * protected Object clone()
   * boolean equals(Object obj)
   * protected void finalize()
   * int hashCode()
   * String toString()
   **/

  // Constructors

  /**
   * Channel needs no default constructor.  Use the channelFactory to get new
   * instances of Channel.
   * @see Channel#channelFactory
   **/

  private Channel();

  // Public Methods

  /**
   * @bon Build and return a new Channel for a particular channel type.
   * @param channelType the channel type to build.
   * @return a new instance of Channel specific to the type passed.
   * @ensures Result is an instance of Channel specific to the channel type
   * specified.
   * @generates A new instance of Channel is built for the channel type in
   * question.  If a Channel for that type has been previously constructed a
   * cached reference to that instance will be returned.
   **/
  public static Channel channelFactory(int channelType);

  /**
   * @bon What are the potential communication properties of this channel?
   * @pre -- none
   * @post (Result == properites)
   * @return the communication properties of this channel.
   * @modifies (QUERY)
   **/
  public ChannelInformation getChannelProperties();
  
  /**
   * @bon What is the current state of this communication channel?
   * @pre -- none
   * @post (Result == state)
   * @return the current state of this channel.
   * @modifies (QUERY)
   **/
  public ChannelInformation getChannelState();
  
  /**
   * @bon Is this channel being used?
   * @pre -- none
   * @ensures Result iff connectorsUsingChannel() is empty
   * @ensures true iff if any connector's channel() method returns this channel.
   * @return a flag indicating if any connector is currently using this channel.
   * @modifies (QUERY)
   **/
  public boolean isInUse();
  
  /**
   * @bon Which connectors are using this channel?
   * @pre -- none
   * @post (Result == connectors)
   * @ensures (for_all e in Result : e.channel() == this)
   * @return a list of connectors using this channel.
   * @modifies (QUERY)
   **/
  public Enumeration connectorsUsingChannel();

  /**
   * @bon What are the current legal channels?
   * @pre -- none
   * @post (Result == channels)
   * @ensures No channel in the enumeration does not extend channel.
   * @ensures No channel that is available is not in the result list.
   * @return a list of the valid channel that exist at this instant in time.
   * @modifies (QUERY)
   * @see All classes that inherit from Channel for the legal set of channels.
   **/
  public static Enumeration legalChannels();

  /**
   * @bon Make this channel available for future connectors.
   * @pre -- none
   * @post ((Result == old enabled) && (enabled == true))
   * @return the previous state of the availability of the channel.
   * @modifies (enabled)
   **/
  public boolean enable();

  /**
   * @bon Make this channel unavailable for future connectors.
   * @pre -- none
   * @post ((Result == old enabled) && (enabled == false))
   * @return the previous state of the availability of the channel.
   * @modifies (enabled)
   **/
  public boolean disable();  

  // Protected Methods

  /**
   * @bon Register a new channel.
   * @pre -- none
   * @ensures (channel in channels)
   * @modifies (channels)
   * @access (PROTECTED)
   **/
  protected void registerChannel(Channel channel);

  /**
   * @bon Unregister a channel.
   * @pre -- none
   * @ensures (channel not in channels)
   * @modifies (channels)
   * @access (PROTECTED)
   **/
  protected void unregisterChannel(Channel channel);

  /**
   * @bon What is the identifier for a channel type?
   * @pre -- none
   * @post -- none
   * @ensures Result is a unique (unused) string that represents this channel
   * type.
   * @example Java streams-based channels might be represented by the string
   * "JAVA1.2-STREAM", shared files might be "SHAREDFLATFILE".
   * @see children See the various children of this class for details.
   **/
  protected String channelIdentifier();

  // Package Methods
  // Private Methods
}
// end of class Channel
  
