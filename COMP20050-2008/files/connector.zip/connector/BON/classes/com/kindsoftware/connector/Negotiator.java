/*
 * The KindSoftware Connector Architecture, Version 0.1
 *
 * Copyright (C) 1999-2001 by KindSoftware, LLC.  All rights reserved.
 *
 * $Id: Negotiator.java 2105 2002-12-29 12:29:18Z kiniry $
 */

package com.kindsoftware.connector;

/**
 * @bon Negotiates the channel properties between components and instantiates
 * the appropriate connector.
 *
 * @version $Revision: 2105 $ $Date: 2002-12-29 12:29:18 +0000 (Sun, 29 Dec 2002) $
 * @author Joseph Kiniry <kiniry@kindsoftware.com>
 **/

public abstract class Negotiator extends Object
{
  // Inherited Methods
  
  /**
   * The default behavior of the following methods is correct:
   *
   * protected Object clone()
   * boolean equals(Object obj)
   * protected void finalize()
   * int hashCode()
   * String toString()
   **/

  // Constructors

  /**
   * This is a default constructor. It does nothing of consequence.
   **/

  public Negotiator();

  // Public Methods

  /**
   * @bon Bind a set of components together into a specified topology.
   * @pre -- none
   * @post -- none
   * @param components the set of components to compose.
   * @return a flag indicating the success/failure of the composition.
   **/
  public boolean compose(Vector components);

  // Protected Methods
  // Package Methods
  // Private Methods
}
// end of class Negotiator
