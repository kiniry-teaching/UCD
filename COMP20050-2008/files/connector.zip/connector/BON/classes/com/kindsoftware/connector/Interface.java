/*
 * The KindSoftware Connector Architecture, Version 0.1
 *
 * Copyright (C) 1999-2001 by KindSoftware, LLC.  All rights reserved.
 *
 * $Id: Interface.java 2105 2002-12-29 12:29:18Z kiniry $
 */

package com.kindsoftware.connector;

/**
 * An interface is a named set of SDOs.  They are used to describe components.
 *
 * @version $Revision: 2105 $ $Date: 2002-12-29 12:29:18 +0000 (Sun, 29 Dec 2002) $
 * @author Joseph Kiniry <kiniry@kindsoftware.com>
 *
 * @bon A named set of SDOs used to describe an interface of a component.
 * @concurrency (CONCURRENT)
 **/

public abstract class Interface extends Object
{
  // Attributes

  /**
   * The name of this interface.
   * @invariant (name != null)
   **/
  private String name;

  /**
   * The SDO set that describes this interface.
   * @invariant (SDOs != null)
   **/
  private Vector SDOs;

  // Inherited Methods

  /**
   * The default behavior of the following methods is correct:
   *
   * protected Object clone()
   * boolean equals(Object obj)
   * protected void finalize()
   * int hashCode()
   **/

  /**
   * @return a decent, parsable string representation of the interface.
   * @pre -- none
   * @post (Result != null)
   * @todo Design this representation.
   **/
  public String toString();

  // Constructors

  /**
   * Create a new interface with the specified name.
   *
   * @param name the name of the interface.
   **/
  public Interface(String name);

  // Public Methods

  /**
   * Get the name of this interface.
   *
   * @bon What is the name of this interface?
   * @return the name of this interface.
   * @pre -- none
   * @post (Result.equals(name))
   * @modifies (QUERY)
   **/
  public String getName();

  /**
   * Add an SDO to this interface.
   *
   * @bon Add an SDO to this interface.
   * @param sdo the SDO to add.
   * @pre (sdo != null)
   * @post (sdo in getSDOs())
   **/
  public void addSDO(SDO sdo);

  /**
   * Returns a list of SDOs in this interface.
   *
   * @bon What are the SDOs that describe this interface?
   * @return a list of SDOs in this interface.  The Enumeration contains SDO
   * instances.
   * @pre -- none
   * @post (Result != null)
   **/
  public Enumeration getSDOs();

  // Protected Methods
  // Package Methods
  // Private Methods
} // end of class Interface
