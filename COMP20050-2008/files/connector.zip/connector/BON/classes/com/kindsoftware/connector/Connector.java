/*
 * The KindSoftware Connector Architecture, Version 0.1
 *
 * Copyright (C) 1999-2001 by KindSoftware, LLC.  All rights reserved.
 *
 * $Id: Connector.java 2105 2002-12-29 12:29:18Z kiniry $
 */

package com.kindsoftware.connector;

/**
 * @bon A connector between two or more components.
 *
 * @version $Revision: 2105 $ $Date: 2002-12-29 12:29:18 +0000 (Sun, 29 Dec 2002) $
 * @author Joseph Kiniry <kiniry@kindsoftware.com>
 *
 * @invariant All connectors have legal levels.
 * @invariant All connectors have a legal name.
 * @invariant The components associated with a connector are exactly the
 * connector associated with the components.
 *
 * The other class-level tags are:
 * @history @review @todo @idea @requires @modifies @invariant
 * @concurrency @deprecated @since @bon @equivalent @example @see
 * @link @design @references @uses
 **/

public abstract class Connector extends Object
{
  // Attributes

  /**
   * The current level of this connector.
   **/
  private int level;

  /**
   * The current network utilization in kilobytes per second (kB/sec).
   * @invariant (utilization >= 0.0)
   **/
  private float utilization;

  /**
   * The name of this connector.
   * @invariant (name != null)
   **/
  private String name;

  /**
   * The channel used by this connector.
   * @invariant (channel != null)
   **/
  private Channel channel;

  /**
   * A list of the components attached to this connector.
   * @invariant ((components != null) && (forall i in components : i <: Component))
   * @invariant (forall i in components : this in i.connectors())
   **/
  private Vector components;

  /**
   * A flag indicating if this connector is closed.
   **/
  private boolean closed = false;

  // Inherited Methods

  /**
   * The default behavior of the following methods is correct:
   *
   * protected Object clone()
   * boolean equals(Object obj)
   * protected void finalize()
   * int hashCode()
   **/
  
  /**
   * @return a decent, parsable string representation of the connector.
   * @pre -- none
   * @post (Result != null)
   * @todo Design this representation.
   **/
  public String toString();

  // Constructors

  /**
   * Create a new connector.
   *
   * @bon Set the name of this connector.
   * @param name the name of this connector.
   **/
  public Connector(String name);

  // Public Methods

  /**
   * @bon What is the current level of this connector?
   * @pre -- none
   * @post (Result == level)
   * @return the current level of this connector.
   **/
  public int level();
  
  /**
   * @bon What is the current network utilization?
   * @pre -- none
   * @post (Result == utilization)
   * @return the current network utilization of this connector in kB/sec.
   **/
  public float utilization();
  
  /**
   * @bon What is the name of this connector?
   * @pre -- none
   * @post (Result.equals(name))
   * @return the name of this connector.
   **/
  public String name();
  
  /**
   * @bon Which channel is used by this connector?
   * @pre -- none
   * @post (Result == channel)
   * @return the channel used by this connector.
   **/
  public Channel channel();
  
  /**
   * @bon Which components are attached to this connector?
   * @pre -- none
   * @post (Result.equals(components))
   * @return the components attached to (using) this connector.
   **/
  public Enumeration components();
  
  /**
   * @bon Send SDO.
   * @pre (sdo != null)
   * @ensures The SDO is added to the sending queue
   **/
  public void send(SDO sdo);
  
  /**
   * Receives the next SDO received via this connector.  This method is
   * blocking.  If a SDO never arrives on the connector, this method never
   * returns.
   *
   * @bon Receive SDO.
   * @pre -- none
   * @post (Result != null)
   * @return the next SDO received via this connector.
   **/
  public SDO receive();
  
  /**
   * @bon Close this connector.
   * @pre -- none
   * @post (closed == true)
   **/
  public void close();
  
  // Protected Methods
  // Package Methods
  // Private Methods
}
// end of class Connector
