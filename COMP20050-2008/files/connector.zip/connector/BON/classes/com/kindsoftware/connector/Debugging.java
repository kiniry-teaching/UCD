/*
 * The KindSoftware Connector Architecture, Version 0.1
 *
 * Copyright (C) 1999-2001 by KindSoftware, LLC.  All rights reserved.
 *
 * $Id: Debugging.java 2105 2002-12-29 12:29:18Z kiniry $
 */

package com.kindsoftware.connector;

/**
 * @bon Enable, disable, and fine-tune debugging information within the
 * Connector architecture.
 *
 * @version $Revision: 2105 $ $Date: 2002-12-29 12:29:18 +0000 (Sun, 29 Dec 2002) $
 * @author Joseph Kiniry <kiniry@kindsoftware.com>
 * @invariant All reference attributes are non-null.
 * @todo joe - Add more tunability as implementations evolve.
 **/

public abstract class Debugging extends Object
{
  // Attributes

  /**
   * A flag that indicates if debugging is enabled.
   **/
  private boolean enabled = false;

  /**
   * A list of channels on which debugging is enabled.
   **/
  private Vector enabledChannels;

  /**
   * A list of connectors on which debugging is enabled.
   **/
  private Vector enabledConnectors;

  // Inherited Methods

  /**
   * The default behavior of the following methods is correct:
   *
   * protected Object clone()
   * boolean equals(Object obj)
   * protected void finalize()
   * int hashCode()
   **/

  /**
   * @return a decent, parsable string representation of the debugging state
   * of the Connector system.
   * @pre -- none
   * @post (Result != null)
   * @todo Design this representation.
   **/
  public String toString();

  // Constructors

  /**
   * This is a default constructor. It does nothing of consequence.
   **/
  public Debugging();

  // Public Methods

  /**
   * @bon Is debugging enabled?
   * @modifies (QUERY)
   **/
  public boolean enabled();
  
  /**
   * @bon Is debugging enabled on a particular channel type?
   * @modifies (QUERY)
   * @param channel the channel to check.
   * @return a flag indicating if debugging is enabled.
   **/
  public boolean enabled(Channel channel);
  
  /**
   * @bon Is debugging enabled on a particular connector? 
   * @modifies (QUERY)
   * @param connector the connector to check.
   * @return a flag indicating if debugging is enabled.
   **/
  public boolean enabled(Connector connector);

  /**
   * @bon Enable debugging on a particular channel type.
   * @modifies (enabledChannels)
   * @param channel the channel to tweak.
   **/
  public void enable(Channel channel);
  
  /**
   * @bon Disable debugging on a particular channel type.
   * @modifies (enabledChannels)
   * @param channel the channel to tweak.
   **/
  public void disable(Channel channel);

  /**
   * @bon Enable debugging on a particular connector.
   * @modifies (enabledConnectors)
   * @param connector the connector to tweak.
   **/
  public void enable(Connector connector);

  /**
   * @bon Disable debugging on a particular connector.
   * @modifies (enabledConnectors)
   * @param connector the connector to tweak.
   **/
  public void disable(Connector connector);

  // Protected Methods
  // Package Methods
  // Private Methods
}
// end of class Debugging
